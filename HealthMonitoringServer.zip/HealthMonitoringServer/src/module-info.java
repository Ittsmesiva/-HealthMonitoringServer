/**
 * 
 */
/**
 * 
 */
module HealthMonitoringServer {
	requires nanohttpd;
}